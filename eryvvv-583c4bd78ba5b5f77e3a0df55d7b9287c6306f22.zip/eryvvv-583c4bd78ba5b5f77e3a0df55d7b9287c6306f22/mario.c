#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int n;

    // prompt user for height
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1 || n > 8);

    // printing the pyramid
    for (int i = 0; i < n; i++)
    {
        // print the spaces
        for (int j = n; j > (i + 1); j--)
        {
            printf(" ");
        }

        // print the hashes
        for (int k = 0; k < (i + 1); k++)
        {
            printf("#");
        }
        printf("\n");
    }
}